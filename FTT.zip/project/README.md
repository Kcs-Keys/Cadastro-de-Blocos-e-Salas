# UniEVANGÉLICA Room Reservation System

A REST API for managing academic room reservations at UniEVANGÉLICA.

## Features

- Block and room management
- Room reservation system with conflict detection
- Recurring reservations support
- Usage statistics and reporting
- Authentication and authorization
- Room availability checking

## Tech Stack

- Node.js with Express
- TypeScript
- Supabase (PostgreSQL)
- JWT Authentication
- Zod for validation

## Prerequisites

- Node.js 18+
- Supabase account

## Setup

1. Clone the repository
2. Copy `.env.example` to `.env` and fill in your Supabase credentials
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## API Documentation

### Authentication

#### Sign Up
```http
POST /api/auth/signup
Content-Type: application/json

{
  "email": "coordinator@unievangelica.edu.br",
  "password": "secure123",
  "name": "John Doe",
  "course": "Computer Science"
}
```

#### Sign In
```http
POST /api/auth/signin
Content-Type: application/json

{
  "email": "coordinator@unievangelica.edu.br",
  "password": "secure123"
}
```

### Blocks

#### List Blocks
```http
GET /api/blocks
Authorization: Bearer <token>
```

#### Create Block
```http
POST /api/blocks
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Block A",
  "code": "BLA"
}
```

### Rooms

#### List Rooms
```http
GET /api/rooms
Authorization: Bearer <token>
```

#### Create Room
```http
POST /api/rooms
Authorization: Bearer <token>
Content-Type: application/json

{
  "block_id": "123e4567-e89b-12d3-a456-426614174000",
  "number": "101",
  "capacity": 40,
  "resources": {
    "projector": true,
    "computers": 20
  },
  "restricted_to_courses": ["Computer Science"]
}
```

#### Check Room Availability
```http
GET /api/rooms/:id/availability?start_time=2024-03-10T08:00:00Z&end_time=2024-03-10T10:00:00Z
Authorization: Bearer <token>
```

### Reservations

#### List Reservations
```http
GET /api/reservations
Authorization: Bearer <token>
```

#### Create Reservation
```http
POST /api/reservations
Authorization: Bearer <token>
Content-Type: application/json

{
  "room_id": "123e4567-e89b-12d3-a456-426614174000",
  "coordinator_id": "123e4567-e89b-12d3-a456-426614174001",
  "start_time": "2024-03-10T08:00:00Z",
  "end_time": "2024-03-10T10:00:00Z",
  "purpose": "Database class",
  "is_recurring": true,
  "recurrence_pattern": {
    "frequency": "weekly",
    "day": "monday",
    "until": "2024-06-30T23:59:59Z"
  }
}
```

#### Cancel Reservation
```http
DELETE /api/reservations/:id
Authorization: Bearer <token>
```

#### Get Usage Statistics
```http
GET /api/reservations/statistics?start_date=2024-03-01T00:00:00Z&end_date=2024-03-31T23:59:59Z
Authorization: Bearer <token>
```

## Security

- JWT-based authentication
- Row Level Security (RLS) in Supabase
- Input validation using Zod
- CORS enabled

## Error Handling

The API uses standard HTTP status codes:

- 200: Success
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 403: Forbidden
- 404: Not Found
- 409: Conflict
- 500: Internal Server Error

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request