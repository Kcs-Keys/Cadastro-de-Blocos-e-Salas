import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../lib/supabase.js';

const router = Router();

const signUpSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(1),
  course: z.string().min(1)
});

const signInSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1)
});

// Sign up
router.post('/signup', async (req, res) => {
  const validation = signUpSchema.safeParse(req.body);
  
  if (!validation.success) {
    return res.status(400).json({ error: validation.error });
  }

  const { email, password, name, course } = validation.data;

  // Create auth user
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password
  });

  if (authError) {
    return res.status(500).json({ error: authError.message });
  }

  // Create coordinator profile
  const { data: coordinatorData, error: coordinatorError } = await supabase
    .from('coordinators')
    .insert({
      id: authData.user?.id,
      name,
      email,
      course
    })
    .select()
    .single();

  if (coordinatorError) {
    return res.status(500).json({ error: coordinatorError.message });
  }

  res.status(201).json({
    user: authData.user,
    coordinator: coordinatorData
  });
});

// Sign in
router.post('/signin', async (req, res) => {
  const validation = signInSchema.safeParse(req.body);
  
  if (!validation.success) {
    return res.status(400).json({ error: validation.error });
  }

  const { email, password } = validation.data;

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    return res.status(401).json({ error: error.message });
  }

  res.json(data);
});

export const authRoutes = router;