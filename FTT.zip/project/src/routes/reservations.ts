import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../lib/supabase.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

const reservationSchema = z.object({
  room_id: z.string().uuid(),
  coordinator_id: z.string().uuid(),
  start_time: z.string().datetime(),
  end_time: z.string().datetime(),
  purpose: z.string().min(1),
  is_recurring: z.boolean().optional(),
  recurrence_pattern: z.record(z.string(), z.any()).optional()
});

// Get all reservations
router.get('/', authenticateToken, async (req, res) => {
  const { data, error } = await supabase
    .from('reservations')
    .select(`
      *,
      room:rooms(*),
      coordinator:coordinators(*)
    `)
    .order('start_time');

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.json(data);
});

// Create a new reservation
router.post('/', authenticateToken, async (req, res) => {
  const validation = reservationSchema.safeParse(req.body);
  
  if (!validation.success) {
    return res.status(400).json({ error: validation.error });
  }

  // Check for conflicts
  const { data: conflicts, error: conflictError } = await supabase
    .from('reservations')
    .select('*')
    .eq('room_id', validation.data.room_id)
    .or(`start_time.lte.${validation.data.end_time},end_time.gte.${validation.data.start_time}`);

  if (conflictError) {
    return res.status(500).json({ error: conflictError.message });
  }

  if (conflicts && conflicts.length > 0) {
    return res.status(409).json({
      error: 'Room already reserved for this time period',
      conflicts
    });
  }

  const { data, error } = await supabase
    .from('reservations')
    .insert(validation.data)
    .select()
    .single();

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  // Simulate notification
  console.log(`Reservation created for room ${validation.data.room_id} from ${validation.data.start_time} to ${validation.data.end_time}`);

  res.status(201).json(data);
});

// Cancel a reservation
router.delete('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  const { error } = await supabase
    .from('reservations')
    .delete()
    .eq('id', id);

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.status(204).send();
});

// Get usage statistics
router.get('/statistics', authenticateToken, async (req, res) => {
  const { start_date, end_date } = req.query;

  const { data: reservations, error } = await supabase
    .from('reservations')
    .select(`
      *,
      room:rooms(*)
    `)
    .gte('start_time', start_date)
    .lte('end_time', end_date);

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  // Calculate statistics
  const stats = {
    total_reservations: reservations.length,
    rooms_usage: {},
    peak_hours: {},
    average_duration: 0
  };

  // Process reservations to calculate statistics
  reservations.forEach(reservation => {
    // Room usage count
    const roomId = reservation.room.id;
    stats.rooms_usage[roomId] = (stats.rooms_usage[roomId] || 0) + 1;

    // Peak hours
    const hour = new Date(reservation.start_time).getHours();
    stats.peak_hours[hour] = (stats.peak_hours[hour] || 0) + 1;

    // Calculate duration
    const duration = new Date(reservation.end_time).getTime() - new Date(reservation.start_time).getTime();
    stats.average_duration += duration;
  });

  // Calculate average duration in hours
  stats.average_duration = stats.average_duration / (reservations.length * 3600000);

  res.json(stats);
});

export const reservationRoutes = router;