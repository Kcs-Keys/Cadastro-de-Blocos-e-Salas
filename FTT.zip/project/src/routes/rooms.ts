import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../lib/supabase.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

const roomSchema = z.object({
  block_id: z.string().uuid(),
  number: z.string().min(1),
  capacity: z.number().positive(),
  resources: z.record(z.string(), z.any()).optional(),
  restricted_to_courses: z.array(z.string()).optional()
});

// Get all rooms
router.get('/', authenticateToken, async (req, res) => {
  const { data, error } = await supabase
    .from('rooms')
    .select(`
      *,
      block:blocks(*)
    `)
    .order('number');

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.json(data);
});

// Create a new room
router.post('/', authenticateToken, async (req, res) => {
  const validation = roomSchema.safeParse(req.body);
  
  if (!validation.success) {
    return res.status(400).json({ error: validation.error });
  }

  const { data, error } = await supabase
    .from('rooms')
    .insert(validation.data)
    .select()
    .single();

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.status(201).json(data);
});

// Check room availability
router.get('/:id/availability', authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { start_time, end_time } = req.query;

  if (!start_time || !end_time) {
    return res.status(400).json({ error: 'Missing start_time or end_time' });
  }

  const { data: reservations, error } = await supabase
    .from('reservations')
    .select('*')
    .eq('room_id', id)
    .or(`start_time.lte.${end_time},end_time.gte.${start_time}`);

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.json({
    available: reservations.length === 0,
    conflicting_reservations: reservations
  });
});

export const roomRoutes = router;