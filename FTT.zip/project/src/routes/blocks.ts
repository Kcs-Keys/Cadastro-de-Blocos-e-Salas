import { Router } from 'express';
import { z } from 'zod';
import { supabase } from '../lib/supabase.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

const blockSchema = z.object({
  name: z.string().min(1),
  code: z.string().min(1)
});

// Get all blocks
router.get('/', authenticateToken, async (req, res) => {
  const { data, error } = await supabase
    .from('blocks')
    .select('*')
    .order('name');

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.json(data);
});

// Create a new block
router.post('/', authenticateToken, async (req, res) => {
  const validation = blockSchema.safeParse(req.body);
  
  if (!validation.success) {
    return res.status(400).json({ error: validation.error });
  }

  const { data, error } = await supabase
    .from('blocks')
    .insert(validation.data)
    .select()
    .single();

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  res.status(201).json(data);
});

export const blockRoutes = router;