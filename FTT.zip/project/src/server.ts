import express from 'express';
import cors from 'cors';
import { config } from 'dotenv';
import { blockRoutes } from './routes/blocks.js';
import { roomRoutes } from './routes/rooms.js';
import { reservationRoutes } from './routes/reservations.js';
import { authRoutes } from './routes/auth.js';
import { errorHandler } from './middleware/errorHandler.js';

config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/blocks', blockRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/reservations', reservationRoutes);

// Error handler
app.use(errorHandler);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});