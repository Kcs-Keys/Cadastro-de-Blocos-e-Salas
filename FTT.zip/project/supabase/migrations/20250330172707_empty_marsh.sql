/*
  # Initial Schema for Room Reservation System

  1. Tables
    - blocks
      - id (uuid, primary key)
      - name (text)
      - code (text, unique)
      - created_at (timestamp)
    
    - rooms
      - id (uuid, primary key)
      - block_id (uuid, foreign key)
      - number (text)
      - capacity (integer)
      - resources (jsonb)
      - restricted_to_courses (text[])
      - created_at (timestamp)
    
    - coordinators
      - id (uuid, primary key)
      - name (text)
      - email (text, unique)
      - course (text)
      - created_at (timestamp)
    
    - reservations
      - id (uuid, primary key)
      - room_id (uuid, foreign key)
      - coordinator_id (uuid, foreign key)
      - start_time (timestamp)
      - end_time (timestamp)
      - purpose (text)
      - is_recurring (boolean)
      - recurrence_pattern (jsonb)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create blocks table
CREATE TABLE blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create rooms table
CREATE TABLE rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  block_id uuid REFERENCES blocks(id) ON DELETE CASCADE,
  number text NOT NULL,
  capacity integer NOT NULL,
  resources jsonb DEFAULT '{}',
  restricted_to_courses text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  UNIQUE(block_id, number)
);

-- Create coordinators table
CREATE TABLE coordinators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  course text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create reservations table
CREATE TABLE reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES rooms(id) ON DELETE CASCADE,
  coordinator_id uuid REFERENCES coordinators(id) ON DELETE CASCADE,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  purpose text NOT NULL,
  is_recurring boolean DEFAULT false,
  recurrence_pattern jsonb DEFAULT null,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE coordinators ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow read access to blocks" ON blocks
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow read access to rooms" ON rooms
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow read access to coordinators" ON coordinators
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Allow read access to reservations" ON reservations
  FOR SELECT TO authenticated USING (true);

-- Create indexes for better performance
CREATE INDEX idx_rooms_block_id ON rooms(block_id);
CREATE INDEX idx_reservations_room_id ON reservations(room_id);
CREATE INDEX idx_reservations_coordinator_id ON reservations(coordinator_id);
CREATE INDEX idx_reservations_start_time ON reservations(start_time);
CREATE INDEX idx_reservations_end_time ON reservations(end_time);